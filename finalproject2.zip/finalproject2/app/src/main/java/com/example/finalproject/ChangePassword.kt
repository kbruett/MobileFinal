package com.example.finalproject

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ChangePassword : AppCompatActivity()
{
    var logins = ArrayList<LogIns>()
    var LogInManager: LogInHelper? = null // A reference to the database

    // Username, password, and email fields
    private lateinit var UNtext : EditText
    private lateinit var NewPWtext : EditText
    private lateinit var OldPWtext : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle("Change Your Password?")
        setContentView(R.layout.change_password)

        // Getting context for login manager
        LogInManager = LogInHelper(this)

        // Obtaining previously stored logins
        logins.addAll(LogInManager!!.getAllLogIns)

        // Setting up fields for the username, password, and email
        UNtext = findViewById<EditText>(R.id.UserName)
        OldPWtext = findViewById<EditText>(R.id.PassWord)
        NewPWtext = findViewById<EditText>(R.id.NewPassWord)

        // To change password
        val changepw = findViewById<Button>(R.id.Update)
        changepw.setOnClickListener({
            val textFromUN = UNtext.getText().toString()
            val textFromNewPW = NewPWtext.getText().toString()
            val textFromOldPW = OldPWtext.getText().toString()

            var found = 0
            var foundId = 0.toLong()
            var foundEmail = ""
            var foundUsername = ""

            for (i in 0..(logins.size - 1)) {
                if (logins[i].UserName == textFromUN && logins[i].PassWord == textFromOldPW) {
                    found = 1
                    foundEmail = logins[i].Email
                    foundUsername = logins[i].UserName
                    foundId = logins[i].Id
                    break
                }
            }

            if (found == 1) {
                val changeLogin = LogIns(foundId, foundUsername, textFromNewPW, foundEmail)
                LogInManager!!.updatePassword(changeLogin)
                val existMessage = Toast.makeText(this, "Password changed!", Toast.LENGTH_SHORT)
                existMessage.show()
                this.finish()
            } else {
                val existMessage = Toast.makeText(this, "Incorrect Password or Username!", Toast.LENGTH_SHORT)
                existMessage.show()
            }
        })
    }
}