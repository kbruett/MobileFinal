package com.example.finalproject

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ForgotPassword : AppCompatActivity()
{
    var logins = ArrayList<LogIns>()
    var LogInManager: LogInHelper? = null // A reference to the database

    // Username and email fields
    private lateinit var UNtext : EditText
    private lateinit var Etext : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle("Forgot Your Password?")
        setContentView(R.layout.forgot_password)

        // Getting context for login manager
        LogInManager = LogInHelper(this)

        // Obtaining previously stored logins
        logins.addAll(LogInManager!!.getAllLogIns)

        // Setting up fields for the username and email
        UNtext = findViewById<EditText>(R.id.UserName)
        Etext = findViewById<EditText>(R.id.Email)

        // To obtain your password from your email
        val getpw = findViewById<Button>(R.id.PassWordRequest)
        getpw.setOnClickListener({
            val textFromUN = UNtext.getText().toString()
            val textFromEmail = Etext.getText().toString()

            var found = 0
            var error = 0
            var foundEmail = ""
            var foundPassword = ""

            for (i in 0..(logins.size - 1)) {
                if (logins[i].UserName == textFromUN || logins[i].Email == textFromEmail) {
                    found = 1
                    foundEmail = logins[i].Email
                    foundPassword = logins[i].PassWord
                    break
                }
            }

            if (found == 1) {
                val emailIntent = Intent(Intent.ACTION_SEND)
                emailIntent.data = Uri.parse("mailto:")
                emailIntent.type = "text/plain"
                emailIntent.putExtra(Intent.EXTRA_EMAIL, foundEmail)
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Camera Encryption App - Lost Password")
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Your password is " + foundPassword)

                try {
                    startActivity(Intent.createChooser(emailIntent, "Choose Email Client..."))
                } catch (e: Exception) {
                    error = 1
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }

                if (error == 0) {
                    val existMessage = Toast.makeText(this, "Email sent!", Toast.LENGTH_SHORT)
                    existMessage.show()
                    this.finish()
                }
            } else {
                val existMessage = Toast.makeText(this, "Account not found!", Toast.LENGTH_SHORT)
                existMessage.show()
            }
        })
    }
}