package com.example.finalproject

object EmailConfig
{
    val EMAIL = "MobileAppRutgers@gmail.com"
    val PASSWORD = "MobileAppClass"
}