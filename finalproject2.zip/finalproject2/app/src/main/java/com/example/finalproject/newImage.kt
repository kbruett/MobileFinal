package com.example.finalproject

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationListener
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class newImage : AppCompatActivity() {
    var picPath: String = ""
    val REQUEST_IMAGE_CAPTURE = 1
    val REQUEST_GALLERY_IMAGE = 2
    var timeStamp: String = ""
    private var longitude = 0.0
    private var latitude = 0.0
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private var mGoogleApiClient: GoogleApiClient? = null
    private var mLocation: Location? = null
    private var mLocationManager: LocationManager? = null
    private var mLocationRequest: LocationRequest? = null
    private val listener: LocationListener? = null
    private val update_interval = 60 * 1000 * 5.toLong()
    private val fast_interval = 10 * 1000.toLong()
    private var locationManager: LocationManager? = null
    private val locationListener: LocationListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val intent = getIntent()
        val name = intent.getStringExtra("UN")
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        var LogInManager: LogInHelper? = null // A reference to the database
        LogInManager = LogInHelper(this)

        setTitle("Welcome, " + name)
        setContentView(R.layout.image_screen)

        val takePic = findViewById<View>(R.id.takePicture) as Button
        val uploadPic = findViewById<View>(R.id.galleryUpload) as Button
        val addBtn = findViewById<View>(R.id.addImage) as Button
        val nameET = findViewById<View>(R.id.image_nameET) as EditText
        val addTV = findViewById<View>(R.id.image_addressTV) as TextView
        val timeTV = findViewById<View>(R.id.image_timeTV) as TextView

        takePic.setOnClickListener(View.OnClickListener {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                takePictureIntent.resolveActivity(packageManager)?.also {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                }
            }
        })

        uploadPic.setOnClickListener(View.OnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_GALLERY_IMAGE)
        })

        addBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, PictureScreen::class.java)
            intent.putExtra("UN", name)
            val newPic = PictureHashes(
                0,
                name,
                picPath,
                addTV.text.toString(),
                timeTV.text.toString(),
                nameET.text.toString()
            )
//            if(picPath == "") {
//                val existMessage = Toast.makeText(this, "No Picture was Taken", Toast.LENGTH_SHORT)
//                existMessage.show()
//            }
//            else {
            LogInManager!!.addPicture(newPic)

            startActivity(intent)

//            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val img = findViewById<View>(R.id.imageView) as ImageView
        val timeTV = findViewById<View>(R.id.image_timeTV) as TextView
        val addTV = findViewById<View>(R.id.image_addressTV) as TextView

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data!!.extras!!.get("data") as Bitmap
            img.setImageBitmap(imageBitmap)

            timeStamp = SimpleDateFormat("yyyy-MM-dd--HH:mm:ss").format(Date()).toString()
            //timeStamp = SimpleDateFormat("MM/dd/yyyy HH:mm").format(Date()).toString()
            timeTV.setText(timeStamp)

            //set the address here to the TextView

//            val lat = obtainLatitude()
//            val long = obtainLongitude()
//            val address = getFullAddressFromLatLong(lat,long)
//            addTV.setText(address)

            val reportFilePath = File(getExternalFilesDir(null), "$timeStamp.png")
            picPath = reportFilePath.toString()

            var fos: FileOutputStream
            try {
                fos = FileOutputStream(reportFilePath)
                imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                if (!reportFilePath.exists()) {
                    reportFilePath.createNewFile()
                }
                fos.close()
            } catch (e: Exception) {
                Log.i("DATABASE", "Problem updating pic", e)
                picPath = ""
            }
        }


        if (requestCode == REQUEST_GALLERY_IMAGE && resultCode == RESULT_OK) {
            val contentURI = data!!.data
            val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, contentURI)

            img.setImageBitmap(bitmap)

            timeStamp = SimpleDateFormat("yyyy-MM-dd--HH:mm:ss").format(Date()).toString()
            //timeStamp = SimpleDateFormat("MM/dd/yyyy HH:mm").format(Date()).toString()
            timeTV.setText(timeStamp)

            //set the address here to the TextView

//            val lat = obtainLatitude()
//            val long = obtainLongitude()
//            val address = getFullAddressFromLatLong(lat,long)
//            addTV.setText(address)

            val reportFilePath = File(getExternalFilesDir(null), "$timeStamp.png")
            picPath = reportFilePath.toString()

            var fos: FileOutputStream
            try {
                fos = FileOutputStream(reportFilePath)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                if (!reportFilePath.exists()) {
                    reportFilePath.createNewFile()
                }
                fos.close()
            } catch (e: Exception) {
                Log.i("DATABASE", "Problem updating pic", e)
                picPath = ""
            }

        }
    }

}


//    private fun obtainLatitude(): Double{
//        fusedLocationProviderClient.lastLocation
//            .addOnSuccessListener { location: Location? ->
//                latitude =  location!!.latitude
//                longitude = location!!.longitude
//            }
//        return latitude
//    }
//
//    private fun obtainLongitude(): Double{
//        fusedLocationProviderClient.lastLocation
//            .addOnSuccessListener { location: Location? ->
//                latitude =  location!!.latitude
//                longitude = location!!.longitude
//            }
//        return longitude
//    }
//
//    private fun getFullAddressFromLatLong(latitude: Double, longitude: Double): String? {
//        val geocoder = Geocoder(this, Locale.getDefault())
//        var currentLocationAddress = ""
//
//        try {
//            var addresses: List<Address>? = null
//            addresses = geocoder.getFromLocation(latitude, longitude, 1)
//
//            if(addresses != null && addresses.size > 0)
//                currentLocationAddress = addresses[0].getAddressLine(0)
//
//        } catch (e: IOException){
//            e.printStackTrace()
//        }
//        return currentLocationAddress
//    }

