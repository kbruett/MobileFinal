package com.example.finalproject

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PhotosHelper(context: Context): SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {

        private val DATABASE_NAME = "PhotosDB"
        private val DATABASE_VERSION = 2

        // Picture Hashes Table
        private val PICTURES_TABLE = "PICTURES"
        private val PICTURE_ID = "PICTURE_ID"
        private val USER_ID = "USER_ID"
        private val PICTURE_HASH = "PICTURE_HASH"
        private val ADDRESS = "ADDRESS"
        private val DATE_TIME = "DATE_TIME"
        private val PICTURE_NAME = "PICTURE_NAME"


        private val PICTURE_TABLE = ("CREATE TABLE " + PICTURES_TABLE + "(" +
                PICTURE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + USER_ID + " TEXT, " +
                PICTURE_NAME + " TEXT, " + PICTURE_HASH + " TEXT, " + DATE_TIME + " TEXT, " + ADDRESS + " TEXT " + ");")
    }

    override fun onCreate(p0: SQLiteDatabase) {
        p0.execSQL(PICTURE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase, oldVer: Int, newVer: Int) {
        p0.execSQL("DROP TABLE IF EXISTS " + PICTURES_TABLE)
        onCreate(p0)
    }

    fun addPicture(Image: PictureHashes)
    {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(USER_ID, Image.user_id)
        values.put(PICTURE_HASH, Image.picture_hash)
        values.put(ADDRESS, Image.Address)
        values.put(DATE_TIME, Image.Date_Time)
        values.put(PICTURE_NAME, Image.picture_name)
        Image.picture_id = db.insert(PICTURES_TABLE, null, values)
        db.close()
    }

    fun getImagesForUser(Username: String): ArrayList<PictureHashes?>?
    {
        val db = this.readableDatabase
        val PictureArrayList = ArrayList<PictureHashes?>()


//        val secQuery = "SELECT * FROM $PICTURES WHERE $USER_ID = $Id"
        val secQuery = "SELECT * FROM $PICTURES_TABLE ORDER BY $USER_ID"
        val sCursor = db.rawQuery(secQuery, null)
        if (sCursor.moveToFirst())
        {
            while (sCursor.isAfterLast == false)
            {
                if (sCursor.getString(sCursor.getColumnIndex(USER_ID)) == Username)
                {
                    val PH = PictureHashes()

                    PH.picture_id = sCursor.getLong(sCursor.getColumnIndex(PICTURE_ID))
                    PH.user_id = sCursor.getString(sCursor.getColumnIndex(USER_ID))
                    PH.picture_hash = sCursor.getString(sCursor.getColumnIndex(PICTURE_HASH))
                    PH.Address = sCursor.getString(sCursor.getColumnIndex(ADDRESS))
                    PH.Date_Time = sCursor.getString(sCursor.getColumnIndex(DATE_TIME))
                    PH.picture_name = sCursor.getString(sCursor.getColumnIndex(PICTURE_NAME))
                    PictureArrayList.add(PH)
                }
                sCursor.moveToNext()
            }
        }
        return PictureArrayList
    }

    fun DeleteByName(Image: String, Username: String){
        val db = this.writableDatabase
        db.delete(PICTURES_TABLE , USER_ID + "=? AND " + PICTURE_NAME + "=?", arrayOf(Username, Image))
        db.close()
    }

}
